package com.thrymr.conversion_demo.service;
 import com.thrymr.conversion_demo.dao.EmployeeDAO;
 import com.thrymr.conversion_demo.entities.Employee;
 import com.thrymr.conversion_demo.repository.EmployeeRepository;
 import org.modelmapper.ModelMapper;
 import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class EmployeeService implements EmpService{
    @Autowired
    private EmployeeRepository employeeRepository;
    @Autowired
    public ModelMapper mapper;
    public List<EmployeeDAO> getAll() {
       List<Employee> employees=employeeRepository.findAll();
        return employees.stream().map(employee -> mapper.map(employee,EmployeeDAO.class)).toList();
    }

    @Override
    public EmployeeDAO getEmployee(Integer empId) {
        Optional<Employee> employee=employeeRepository.findById(empId);
        return mapper.map(employee,EmployeeDAO.class);
    }

    public EmployeeDAO addEmployee(EmployeeDAO employeeDAO) {
        Employee employee= mapper.map(employeeDAO,Employee.class);
       return mapper.map(employeeRepository.save(employee),EmployeeDAO.class);
    }

    public EmployeeDAO updateEmployee(EmployeeDAO employeeDAO) {
        Employee employee= mapper.map(employeeDAO,Employee.class);
       return mapper.map(employeeRepository.save(employee),EmployeeDAO.class);
    }

    public boolean deleteEmployee(Integer empId) {
        try {
            employeeRepository.deleteById(empId);
            return true;
        } catch (Exception e) {
            System.out.println(e);
            return false;
        }
    }
}

