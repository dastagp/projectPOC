package com.thrymr.conversion_demo.dao;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@NoArgsConstructor
@AllArgsConstructor
public class EmployeeDAO {
    private Integer empId;
    private String empName;
    private Float empSal;
}
