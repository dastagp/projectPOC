package com.thrymr.conversion_demo.controller;

import com.thrymr.conversion_demo.dao.EmployeeDAO;
import com.thrymr.conversion_demo.entities.Employee;
import com.thrymr.conversion_demo.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/employee")
public class EmployeeController {
    @Autowired
    public EmployeeService employeeService;
    @GetMapping("/get-all")
    public List<EmployeeDAO> getAll(){
        return employeeService.getAll();
    }
    @GetMapping("/get-by-id/{empId}")
    public EmployeeDAO getEmployee(@PathVariable("empId") Integer empId){
       return employeeService.getEmployee(empId);
    }
    @PostMapping("/add")
    public EmployeeDAO addData(@RequestBody EmployeeDAO employeeDAO){
        return employeeService.addEmployee(employeeDAO);
    }
    @PutMapping("/update")
    public EmployeeDAO update(@RequestBody EmployeeDAO employeeDAO){
        return employeeService.updateEmployee(employeeDAO);
    }
    @DeleteMapping("/delete/{empId}")
    public boolean delete(@PathVariable Integer empId){
     return employeeService.deleteEmployee(empId);
    }
}

