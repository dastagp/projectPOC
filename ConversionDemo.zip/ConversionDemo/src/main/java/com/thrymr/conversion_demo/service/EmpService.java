package com.thrymr.conversion_demo.service;

import com.thrymr.conversion_demo.dao.EmployeeDAO;

import java.util.List;

public interface EmpService {
    List<EmployeeDAO> getAll();
    EmployeeDAO getEmployee(Integer empId);
    EmployeeDAO addEmployee(EmployeeDAO employeeDAO);
    EmployeeDAO updateEmployee(EmployeeDAO employeeDAO);
    boolean deleteEmployee(Integer empId);
}

